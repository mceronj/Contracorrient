package com.contracorriente.peripherals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeripheralsApplicationTests {

	@Test
	void contextLoads() {
	}

}
